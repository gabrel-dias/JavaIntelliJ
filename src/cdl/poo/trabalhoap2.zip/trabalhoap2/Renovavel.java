package cdl.poo.trabalhoap2;

public interface Renovavel {
    void renovarContrato();
}
