package cdl.poo.trabalhoap2;

public interface RelatorioGeravel {
    String gerarResumoContrato();
}
