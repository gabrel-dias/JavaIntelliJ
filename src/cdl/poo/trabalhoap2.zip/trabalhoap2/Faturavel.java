package cdl.poo.trabalhoap2;

public interface Faturavel {
    double calcularFatura();
}
